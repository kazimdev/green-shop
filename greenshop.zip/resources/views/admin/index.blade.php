@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
    <h1>Admin Dashboard</h1>
    <p>This is the dashoboard page content.</p>
@endsection
