@extends('layouts.app')

@section('title', 'Products')

@section('content')
<h1>Show Products List Here...</h1>
@endsection