@extends('layouts.app')

@section('title', 'Orders')

@section('content')
<h1>Show Orders List Here...</h1>
@endsection