const Loader = () => {
    return <span className="loading loading-bars loading-xl"></span>
}

export default Loader;