# GreenShop

## An E-Commerce Website created with Laravel + React
